<?php

return  [
    'server_key' => env('MIDTRANS_SERVER_KEY', null),
    'isProduction' => env('MIDTRANS_IS_PRODUCTION', false),
    'isSanitized' => env('MINDTRANS_IS_SANITIZE', true),
    'is_3ds' => env('MIDTRANS_IS_3DS', true),

];

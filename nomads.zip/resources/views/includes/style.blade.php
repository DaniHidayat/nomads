<link rel="stylesheet" href="{{ url('frontend/libraries/bootstrap/css/bootstrap.css') }}" />
<link href="https://fonts.googleapis.com/css2?family=Assistant:wght@300;400&family=Playfair+Display&display=swap"
    rel="stylesheet">
<link rel="stylesheet" href="{{ url('frontend/styles/main.css') }}" />

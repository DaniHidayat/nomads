<?php $__env->startPush('table-style'); ?>
 <link href="<?php echo e(url('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
 <!-- Begin Page Content -->
 <div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0 text-gray-800"> Gallery</h1>

      
      <?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button>
					<strong><?php echo e($message); ?></strong>
				</div>
                <?php endif; ?>
                
                 <?php if($message = Session::get('update')): ?>
				<div class="alert alert-warning alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button>
					<strong><?php echo e($message); ?></strong>
				</div>
                <?php endif; ?>
                
                <?php if($message = Session::get('delete')): ?>
				<div class="alert alert-danger alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button>
					<strong><?php echo e($message); ?></strong>
				</div>
				<?php endif; ?>
        <a href="<?php echo e(route('gallery.create')); ?>" class="btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50">Tambah Gallery </i>
        </a>
    </div>

<!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Travel</th>
                            <th>Gambar</th>
                            <th>Action</>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->travel_package->title); ?></td>
                        <td><img src="<?php echo e(Storage:: url($item->image)); ?>" alt="" style="width:150px" class="img-thumbnail">
                        </td>
                        <td><a href="<?php echo e(route('gallery.edit', $item->id)); ?>" class="btn btn-info">
                            <i class="fa fa-pencil-alt"></i>
                        </a>
                        <a href="#" data-toggle="modal" data-target="#delete<?php echo e($item->id); ?>" class="btn btn-danger">
                            <i class="fa fa-trash-alt"></i>
                        </a>

                        </td>
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                            <td colspan="7" class="text-center">
                                Data kosong
                            </td>

                        </tr>
                    <?php endif; ?>
                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

  </div>
  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


   <!-- Delete Modal-->
  <div class="modal fade" id="delete<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Are you sure? for delete this <?php echo e($item->title); ?> ?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        
        <div class="modal-footer">
          <form action="<?php echo e(route('gallery.destroy', $item->id)); ?>" method="POST" class="d-inline ">
                         <?php echo csrf_field(); ?>
                         <?php echo method_field('delete'); ?>
                         <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" type="submit" >Delete</button>
                        </form>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__env->startPush('table-script'); ?>
<!-- Page level plugins -->
    <script src="<?php echo e(url('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(url('backend/js/demo/datatables-demo.js')); ?>"></script>
  <?php $__env->stopPush(); ?>
  <!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nomads\resources\views/pages/admin/gallery/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    TEST
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main>
<section class="about" id="about">
<div class="container">
    <div class="row mb-4">
        <div class="col text-center">
            <h2>About</h2>
        </div>
    </div>
    <div class="row justify-content-center">
    <div class="col-md-5">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, molestiae sunt doloribus error ullam expedita cumque blanditiis quas vero, qui, consectetur modi possimus. Consequuntur optio ad quae possimus, debitis earum.</p>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, molestiae sunt doloribus error ullam expedita cumque blanditiis quas vero, qui, consectetur modi possimus. Consequuntur optio ad quae possimus, debitis earum.</p>
            </div>
            <div class="col-md-6">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, molestiae sunt doloribus error ullam expedita cumque blanditiis quas vero, qui, consectetur modi possimus. Consequuntur optio ad quae possimus, debitis earum.</p>
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, molestiae sunt doloribus error ullam expedita cumque blanditiis quas vero, qui, consectetur modi possimus. Consequuntur optio ad quae possimus, debitis earum.</p>
    </div>
    </div>
</div>
</section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.checkout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nomads\resources\views/pages/test.blade.php ENDPATH**/ ?>